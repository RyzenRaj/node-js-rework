const express = require('express');
const db = require('./connection'); 

const app = express();
const PORT = 4000;

// Middleware to parse JSON requests
app.use(express.json());

// Create the employees table
app.post('/create', (req, res) => {
    
    const checkTableQuery = `
        SELECT COUNT(*) AS count
        FROM information_schema.tables 
        WHERE table_schema = 'employee' 
        AND table_name = 'employees';
    `;

    db.query(checkTableQuery, (err, results) => {
        if (err) {
            return res.status(500).json(err);
        }

        // Check if the table already exists
        if (results[0].count > 0) {
            return res.status(400).json({ message: "Employees table already exists!" });
        }

        // Table does not exist, proceed to create it
        const createTableQuery = `
            CREATE TABLE employees (
                id INT AUTO_INCREMENT PRIMARY KEY,
                first_name VARCHAR(255) NOT NULL,
                last_name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                phone VARCHAR(15),
                position VARCHAR(100),
                hire_date DATE,
                salary DECIMAL(10, 2),
                is_deleted BOOLEAN DEFAULT FALSE

            );
        `;

        db.query(createTableQuery, (err, results) => {
            if (err) {
                return res.status(500).json(err);
            }
            res.status(200).json({ message: "Employees table created successfully!" });
        });
    });
});

// show all the employees 
app.get('/employees1', (req, res) => {
    const query = `SELECT * FROM employees where is_deleted = 0`;

    db.query(query, (err, results) => {
        if (err) {
            // Send back the error response if there's an error
            return res.status(500).json({ error: err.message });
        }

        // If no error, send back the results as JSON
        res.status(200).json(results);
    });
});


// show all the employees in html table format 
app.get('/employees', (req, res) => {
    const query = `SELECT * FROM employees where is_deleted = 0`;

    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        // Create an HTML table
        let html = `
            <html>
                <head>
                    <title>Employee List</title>
                    <style>
                        table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        th, td {
                            border: 1px solid #ddd;
                            padding: 8px;
                            text-align: left;
                        }
                        th {
                            background-color: #f2f2f2;
                        }
                    </style>
                </head>
                <body>
                    <h1>Employee List</h1>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Position</th>
                                <th>Hire Date</th>
                                <th>Salary</th>
                            </tr>
                        </thead>
                        <tbody>`;

        // Populate the table rows with employee data
        results.forEach(employee => {
            html += `
                            <tr>
                                <td>${employee.id}</td>
                                <td>${employee.first_name}</td>
                                <td>${employee.last_name}</td>
                                <td>${employee.email}</td>
                                <td>${employee.phone}</td>
                                <td>${employee.position}</td>
                                <td>${employee.hire_date}</td>
                                <td>${employee.salary}</td>
                            </tr>`;
        });

        html += `
                        </tbody>
                    </table>
                </body>
            </html>`;

        // Send the HTML response
        res.status(200).send(html);
    });
});

// add new employee with json body 
app.post('/add-employee', (req, res) => {
   
    const { first_name, last_name, email, phone, position, hire_date, salary } = req.body;

    const insertQuery = `
        INSERT INTO employees (first_name, last_name, email, phone, position, hire_date, salary)
        VALUES (?, ?, ?, ?, ?, ?, ?);
    `;

    
    db.query(insertQuery, [first_name, last_name, email, phone, position, hire_date, salary], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message }); 
        }

       
        res.status(201).json({ message: "Employee added successfully!", employeeId: results.insertId });
    });
});


//soft delete employee
app.post('/delete-employee', (req, res) => {
    
    const { id: employeeId } = req.body;

 
    if (!employeeId) {
        return res.status(400).json({ message: "Employee ID is required." });
    }

 
    const softDeleteQuery = `
        UPDATE employees
        SET is_deleted = TRUE
        WHERE id = ?;
    `;

    db.query(softDeleteQuery, [employeeId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
            // 500 server
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ message: "Employee not found." });
            
        }

        res.status(200).json({ message: "Employee soft deleted successfully!" });
    });
});


app.get('/employees', (req, res) => {
    const query = `SELECT * FROM employees`; // Fetch all employees including deleted ones

    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        // Create an HTML table
        let html = `
            <html>
                <head>
                    <title>Employee List</title>
                    <style>
                        table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        th, td {
                            border: 1px solid #ddd;
                            padding: 8px;
                            text-align: left;
                        }
                        th {
                            background-color: #f2f2f2;
                        }
                    </style>
                </head>
                <body>
                    <h1>Employee List</h1>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Position</th>
                                <th>Hire Date</th>
                                <th>Salary</th>
                                <th>Action</th> <!-- New Action Column -->
                            </tr>
                        </thead>
                        <tbody>`;

        // Populate the table rows with employee data
        results.forEach(employee => {
            html += `
                            <tr>
                                <td>${employee.id}</td>
                                <td>${employee.first_name}</td>
                                <td>${employee.last_name}</td>
                                <td>${employee.email}</td>
                                <td>${employee.phone}</td>
                                <td>${employee.position}</td>
                                <td>${employee.hire_date}</td>
                                <td>${employee.salary}</td>
                                <td>`;
            // Check if the employee is deleted
            if (employee.is_deleted) {
                html += `<button onclick="undoDelete(${employee.id})">Undo</button>`;
            }
            html += `</td></tr>`;
        });

        html += `
                        </tbody>
                    </table>

                    <script>
                        function undoDelete(id) {
                            fetch('/employees/undo/' + id, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.message) {
                                    alert(data.message);
                                    location.reload(); // Reload the page to see changes
                                } else {
                                    alert('Error restoring employee');
                                }
                            })
                            .catch((error) => {
                                console.error('Error:', error);
                                alert('Error restoring employee');
                            });
                        }
                    </script>
                </body>
            </html>`;

        // Send the HTML response
        res.status(200).send(html);
    });
});











// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
